describe('contain', function() {
  it('match', function() {
    browser.get('http://acadgild.com/');

    expect(browser.getTitle()).toContain('acadgild');
  });
});